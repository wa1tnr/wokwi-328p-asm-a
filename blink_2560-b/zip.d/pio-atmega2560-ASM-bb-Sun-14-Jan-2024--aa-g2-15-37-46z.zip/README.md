#### Sun 14 Jan 15:37:46 UTC 2024

## solid program.  14 Jan 2024.

  ATMega 2560:

  latest work (+pio +wokwi_proven):

  https://wokwi.com/projects/386911892649584641


  https://wokwi.com/projects/386905436315146241

  https://wokwi.com/projects/386905237448504321

  reduced times 09:26z Sun 14 Jan 2024:
  https://wokwi.com/projects/386888443979857921

  bounce-back tested 09:15z:
  https://wokwi.com/projects/386887722864670721


  a few revisions saved no real changes, ends on:
  https://wokwi.com/projects/386886127887171585

  looking good at 08:25 UTC for Sunday 14 Jan 2024:

  https://wokwi.com/projects/386883941252721665

  more solid use of com or and &c. here:

  https://wokwi.com/projects/386879831463775233

  proof (bounceback git > wokwi last step):
  https://wokwi.com/projects/386869812993004545

  latest:
  https://wokwi.com/projects/386866832786825217

  older:
  https://wokwi.com/projects/386865981692263425
  https://wokwi.com/projects/386859937020562433

ENiD,


#### Fri Aug  4 22:25:02 UTC 2023

##### latest:

Updated moments afte the below 'Progress!' report. ;)

  https://wokwi.com/projects/372170908061497345


Progress!  Found the diaspora upstream stuff and the
compatibility issues arising.

  https://wokwi.com/projects/372169757470559233


older:

Sorting this a bit.  Some printing in the serial setup.

  https://wokwi.com/projects/372155578052061185


PB5 was already spoken for and did not notice.
Changed them all to an lc 'n' prefix, but did not
do exhaustive search for these.

  https://wokwi.com/projects/372152879278481409



Good.  LEDs blink individually.  Experimented a lot
with the syntax to do so.

  https://wokwi.com/projects/372142687446556673

  https://wokwi.com/projects/372132232507879425

  https://wokwi.com/projects/372113258587831297

  as copied from github into new wokwi project, for symmetry
  in synchronization. ;)

## END.